package com.cg.ars.services;


import java.sql.Date;
import java.util.List;

import com.cg.ars.entities.BookingInformation;
import com.cg.ars.entities.FlightInfo;
import com.cg.ars.entities.UserClass;
import com.cg.ars.exceptions.BookingExceptions;


public interface BookingServices {
	public List<FlightInfo> showAll() throws BookingExceptions;
	public FlightInfo flightDetails(String flightno) throws BookingExceptions;
	public BookingInformation addBookingDetails(BookingInformation book,String no)throws BookingExceptions;
	public boolean cancelBooking(String bookid) throws BookingExceptions; 
	public BookingInformation showBookingId(String email) throws BookingExceptions;
	UserClass getUserDetails(String userName) throws BookingExceptions;
	boolean isUserAuthenticated(String userName,String password)throws BookingExceptions;
	BookingInformation showBookingDetails(String bookId) throws BookingExceptions;
	boolean updateFlightSeatQuantity(String flightno, int noofpassengers,String seattype) throws BookingExceptions;
	public String getFlightNo(String src,String dest) throws BookingExceptions;
	
	public boolean deleteFlight(String no) throws BookingExceptions;
	public boolean insertFlightDetails(FlightInfo info) throws BookingExceptions;
	public boolean insertUser(UserClass users) throws BookingExceptions;
	public List<FlightInfo> searchBySrcDest(String src, String dest) throws BookingExceptions;
	List<FlightInfo> showFlightByDate(Date date) throws BookingExceptions;
	public boolean updateFlightInfo(FlightInfo info) throws BookingExceptions;
	boolean updateFlightSeatQuantityOnCancellation(String flightno,
			int noofpassengers, String seattype) throws BookingExceptions;
	public List<BookingInformation> showPassengerList(String flightno) throws BookingExceptions;
	public boolean updateCancelFlight(String no) throws BookingExceptions;
	public List<BookingInformation> listBookingDetails(String userName) throws BookingExceptions;
		
}
