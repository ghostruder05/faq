package com.cg.ars.services;

import java.sql.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.ars.daos.BookingDao;
import com.cg.ars.daos.BookingDaoImpl;
import com.cg.ars.entities.BookingInformation;
import com.cg.ars.entities.FlightInfo;
import com.cg.ars.entities.UserClass;
import com.cg.ars.exceptions.BookingExceptions;


@Service("bookingService")
@Transactional
public class BookingServicesImpl implements BookingServices{

	private BookingDao dao;
	
	@Resource(name="bookingDao")
	public void setBookingDao(BookingDao dao)
	{
		this.dao=dao;
	}
	
	@Override
	public List<FlightInfo> showAll() throws BookingExceptions {	
		return dao.showAll();
	}

	@Override
	public BookingInformation addBookingDetails(BookingInformation book,String no)
			throws BookingExceptions {
		
		return dao.addBookingDetails(book,no);
	}

	@Override
	public boolean cancelBooking(String bookid) throws BookingExceptions {
		
		return dao.cancelBooking(bookid);
	}
	
	@Override
	public UserClass getUserDetails(String userName) throws BookingExceptions {
	
		return dao.getUserDetails(userName);
	}

	@Override
	public boolean isUserAuthenticated(String userName,String password)throws BookingExceptions{
		UserClass user=dao.getUserDetails(userName);         //check db user with that username
		if(password.equals(user.getPassword()))
		{
			return true;
		}
		else
		{	
		return false;
		}
	
	}

	@Override
	public BookingInformation showBookingDetails(String bookId)
			throws BookingExceptions {
		
		return dao.showBookingDetails(bookId);
	}

	@Override
	public boolean updateFlightSeatQuantity(String flightno,
			int noofpassengers, String seattype) throws BookingExceptions {
	
		return dao.updateFlightSeatQuantity(flightno, noofpassengers, seattype);
	}

	@Override
	public String getFlightNo(String src, String dest) throws BookingExceptions {
		return dao.getFlightNo(src, dest);
	}

	@Override
	public boolean deleteFlight(String no) throws BookingExceptions {
	
		return dao.deleteFlight(no);
	}

	@Override
	public boolean insertFlightDetails(FlightInfo info) throws BookingExceptions {
		return dao.insertFlightDetails(info);
		
	}

	@Override
	public boolean insertUser(UserClass users)
			throws BookingExceptions {

		return dao.insertUsers(users);
	}

	@Override
	public List<FlightInfo> searchBySrcDest(String src, String dest)
			throws BookingExceptions {
		
		return dao.searchBySrcDest(src,dest);
	}

	@Override
	public List<FlightInfo> showFlightByDate(Date date)
			throws BookingExceptions {
		
		return dao.showFlightByDate(date);
	}

	@Override
	public boolean updateFlightInfo(FlightInfo info) throws BookingExceptions {
		
		return dao.updateFlightInfo(info);
	}

	@Override
	public BookingInformation showBookingId(String email) throws BookingExceptions {
		
		return dao.showBookingId(email);
	}

	@Override
	public FlightInfo flightDetails(String flightno) throws BookingExceptions {	
		return dao.flightDetails(flightno);
	}

	@Override
	public boolean updateFlightSeatQuantityOnCancellation(String flightno,
			int noofpassengers, String seattype) throws BookingExceptions {
		
		return dao.updateFlightSeatQuantityOnCancellation(flightno, noofpassengers, seattype);
	}

	@Override
	public List<BookingInformation> showPassengerList(String flightno)
			throws BookingExceptions {
		
		return dao.showPassengerList(flightno);
	}

	@Override
	public boolean updateCancelFlight(String no) throws BookingExceptions {
		
		return dao.updateCancelFlight(no);
	}

	@Override
	public List<BookingInformation> listBookingDetails(String userName)
			throws BookingExceptions {
		
		return dao.listBookingDetails(userName);
	}


	

}
