 package com.cg.ars.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name="bookingInformation")
@Table(name="BOOKINGINFORMATION")
@NamedQueries( { 
	@NamedQuery(name="passList", query= "SELECT b FROM bookingInformation b WHERE flightno is :fno"),
	@NamedQuery(name="bookingIdSelect", query= "SELECT b FROM bookingInformation b WHERE booking_id=:bookId"),
	@NamedQuery(name="setFlightNo", query="SELECT b FROM bookingInformation b WHERE flightno is :fno"),
	@NamedQuery(name="bookList", query= "SELECT b FROM bookingInformation b WHERE userName is :userName"),
	
	//@NamedQuery(name="setFlightNoNull", query="UPDATE bookingInformation SET flightno=null WHERE flightno is :fno")
	
	
	})
@SequenceGenerator(name="Booking_Id_Seq1",sequenceName="Booking_Id_Seq1",allocationSize=1,initialValue=1)
public class BookingInformation {

	private String booking_id;
	private String cust_email;
	private int no_of_passenger;
	private String class_type;
	private int total_fare;
	private int seat_number;
	private String creditcard_info;
	private String src_city;
	private String dest_city;
	private String flightno;
	private String userName;

	
	@Id	
	@GenericGenerator(name="Booking_Id_Seq1",strategy="com.cg.ars.identifierGeneration.StringSequenceGenrator")
	@GeneratedValue(generator="Booking_Id_Seq1",strategy=GenerationType.SEQUENCE)
	@Column(name="BOOKING_ID")
	public String getBooking_id() {
		
		return booking_id;
	}
	

	public void setBooking_id(String booking_id) {
		
		this.booking_id = booking_id;
	}
	
	@Column(name="CUST_EMAIL")
	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	
	@Column(name="NO_OF_PASSENGERS")
	public int getNo_of_passenger() {
		return no_of_passenger;
	}

	public void setNo_of_passenger(int no_of_passenger) {
		this.no_of_passenger = no_of_passenger;
	}
	
	@Column(name="CLASS_TYPE")
	public String getClass_type() {
		return class_type;
	}

	public void setClass_type(String class_type) {
		this.class_type = class_type;
	}
	
	@Column(name="TOTAL_FARE")
	public int getTotal_fare() {
		return total_fare;
	}

	public void setTotal_fare(int total_fare) {
		this.total_fare = total_fare;
	}
	
	@Column(name="SEAT_NUMBERS")
	public int getSeat_number() {
		return seat_number;
	}

	public void setSeat_number(int seat_number) {
		this.seat_number = seat_number;
	}
	
	@Column(name="CREDITCARD_INFO")
	public String getCreditcard_info() {
		return creditcard_info;
	}

	public void setCreditcard_info(String creditcard_info) {
		this.creditcard_info = creditcard_info;
	}
	
	@Column(name="SRC_CITY")
	public String getSrc_city() {
		return src_city;
	}

	public void setSrc_city(String src_city) {
		this.src_city = src_city;
	}
	
	@Column(name="DEST_CITY")
	public String getDest_city() {
		return dest_city;
	}

	public void setDest_city(String dest_city) {
		this.dest_city = dest_city;
	}

	@Column(name="FLIGHTNO")
	public String getFlightno() {
		return flightno;
	}


	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}
	
	
	@Column(name="USERNAME")
	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	@Override
	public String toString() {
		return "BookingInformation [booking_id=" + booking_id + ", cust_email="
				+ cust_email + ", no_of_passenger=" + no_of_passenger
				+ ", class_type=" + class_type + ", total_fare=" + total_fare
				+ ", seat_number=" + seat_number + ", creditcard_info="
				+ creditcard_info + ", src_city=" + src_city + ", dest_city="
				+ dest_city + ", flightno=" + flightno + ", userName="
				+ userName + "]";
	}
	
 	
	
}
