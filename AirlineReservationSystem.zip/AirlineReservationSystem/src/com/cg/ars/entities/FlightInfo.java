package com.cg.ars.entities;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity(name="flightInfo")
@Table(name="FLIGHT_INFORMATION")
@NamedQueries( { 
	@NamedQuery(name="searchBySrcDest", query= "select flightno from flightInfo  where dept_city= :from and arr_city=:to"),	
	@NamedQuery(name="listFlightBySrcDest", query= "select f from flightInfo f where dept_city=:from and arr_city=:to"),
	@NamedQuery(name="showFlightByDate", query= "select f from flightInfo f where dep_date=:depdate"),
	@NamedQuery(name="findFLightonFlightNO", query= "select f from flightInfo f where flightno=:fno"),
	@NamedQuery(name="seatFare" , query="SELECT f FROM flightInfo f where flightno=:fno"),
	@NamedQuery(name="cancelFlight", query="SELECT f FROM flightInfo f where flightno=:fno")
	
	
	})
public class FlightInfo {
	
	private String flightno;
	private String airlinename;
	private String dept_city;
	private String arr_city;
	private Date dep_date;
	private Date arr_date;
	private String dep_time;
	private String arr_time;
	private int firstseats;
	private int firstseatfare;
	private int bussseats;
	private int bussseatfare;
	
	@Id
	@Column(name="FLIGHTNO")
	public String getFlightno() {
		return flightno;
	}


	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}

	@Column(name="AIRLINE")
	public String getAirlinename() {
		return airlinename;
	}


	public void setAirlinename(String airlinename) {
		this.airlinename = airlinename;
	}

	@Column(name="DEP_CITY")
	public String getDept_city() {
		return dept_city;
	}


	public void setDept_city(String dept_city) {
		this.dept_city = dept_city;
	}

	@Column(name="ARR_CITY")
	public String getArr_city() {
		return arr_city;
	}


	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}

	@Column(name="DEP_DATE")
	public Date getDep_date() {
		return dep_date;
	}


	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}

	@Column(name="ARR_DATE")
	public Date getArr_date() {
		return arr_date;
	}


	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}

	@Column(name="DEP_TIME")
	public String getDep_time() {
		return dep_time;
	}


	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}

	@Column(name="ARR_TIME")
	public String getArr_time() {
		return arr_time;
	}


	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}

	@Column(name="FIRSTSEATS")
	public int getFirstseats() {
		return firstseats;
	}


	public void setFirstseats(int firstseats) {
		this.firstseats = firstseats;
	}

	@Column(name="FIRSTSEATFARE")
	public int getFirstseatfare() {
		return firstseatfare;
	}


	public void setFirstseatfare(int firstseatfare) {
		this.firstseatfare = firstseatfare;
	}

	@Column(name="BUSSSEATS")
	public int getBussseats() {
		return bussseats;
	}


	public void setBussseats(int bussseats) {
		this.bussseats = bussseats;
	}

	@Column(name="BUSSSEATSFARE")
	public int getBussseatfare() {
		return bussseatfare;
	}


	public void setBussseatfare(int bussseatfare) {
		this.bussseatfare = bussseatfare;
	}


	@Override
	public String toString() {
		return "FlightInfo [flightno=" + flightno + ", airlinename="
				+ airlinename + ", dept_city=" + dept_city + ", arr_city="
				+ arr_city + ", dep_date=" + dep_date + ", arr_date="
				+ arr_date + ", dep_time=" + dep_time + ", arr_time="
				+ arr_time + ", firstseats=" + firstseats + ", firstseatfare="
				+ firstseatfare + ", bussseats=" + bussseats
				+ ", bussseatfare=" + bussseatfare + "]";
	}
	

}
