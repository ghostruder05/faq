package com.cg.ars.controllers;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ars.entities.BookingInformation;
import com.cg.ars.entities.FlightInfo;
import com.cg.ars.entities.UserClass;
import com.cg.ars.exceptions.BookingExceptions;
import com.cg.ars.services.BookingServices;


@Controller
public class FrontController {

private BookingServices services;
private ServletContext ctx;

	@PostConstruct            //will run automatically
	public void initialize()
	{
		
		//ctx=super.getServletContext();
	}
	
	@Resource(name="bookingService")
	public void setBookingServices(BookingServices services)
	{
		this.services=services;
	}
	
	//Home Page
	@RequestMapping("/home.do")
	public ModelAndView getWelcomePage(){

		ModelAndView model=new ModelAndView("home");//jsp file name
		return model;	
	}
	
	//Login Page
	@RequestMapping("/login.do")
	public ModelAndView getLoginPage(){
		ModelAndView model=new ModelAndView("login");//jsp file name
		return model;	
	}
	
	//About Us Page
	@RequestMapping("/aboutUs.do")
	public ModelAndView getAboutUsPage(){
		ModelAndView model=new ModelAndView("aboutUs");//jsp file name
		return model;	
	}
	
	//Contact Us Page
	@RequestMapping("/contactUs.do")
	public ModelAndView getContactPage(){
		ModelAndView model=new ModelAndView("contactUs");//jsp file name
		return model;	
	}

	//Do Authentication and Login
	@RequestMapping("/successLogin.do")
	public ModelAndView authenticate(@RequestParam("userNm") String userName,@RequestParam("password") String password,HttpSession session){
	
		//String userName = request.getParameter("userNm");
		//String password = request.getParameter("password");
		System.out.println(userName);
		System.out.println(password);
		String admin="admin";
		String executive="executive";
		ModelAndView model=null;
		try {
	
		boolean result=services.isUserAuthenticated(userName,password);
		System.out.println("Authentic user"+result);
		
		if(result)
		{
			if(userName.equals(admin)){
				session.setAttribute("user", admin);
				
				System.out.println("session id:"+session.getId());				
				//ctx.log("Valid user session started with id"+session.getId());
				model=new ModelAndView("adminHome");
				model.addObject("user", userName);
				
				
			}else if(userName.equals(executive)){
				
				session.setAttribute("user", executive);
				//ctx.log("Valid user session started with id"+session.getId());
				model=new ModelAndView("airLineExecutive");
				String eUserName = "Executive";
				model.addObject("user", eUserName);
				
			}else{
				
				session.setAttribute("user",userName);
				//ctx.log("Valid user session started with id"+session.getId());
				model=new ModelAndView("userFunctions");
				model.addObject("user",userName);
			}
		}
	else
		{
			String errMsg="Invalid UserName or Password";
			model=new ModelAndView("login");
			model.addObject("errMsg",errMsg);
		}
		
	} catch (BookingExceptions e) {
		String errMsg="Invalid UserName or Password";
		model=new ModelAndView("login");
		model.addObject("errMsg",errMsg);
	
	}catch (Exception e1){
		String errMsg="Invalid UserName or Password";
		model=new ModelAndView("login");
		model.addObject("errMsg",errMsg);
	}
		
		return model;
	}

	@RequestMapping("/adminUpdate.do")
	public ModelAndView adminUpdate(HttpSession session) {
		ModelAndView model = null;
		System.out.println("in controlling method");
		String user=(String) session.getAttribute("user");
		if(user.equals("admin")){	
		
			model = new ModelAndView("adminHome");
			model.addObject("user", user);
		}else if(user.equals("executive")){
			model = new ModelAndView("airLineExecutive");
			model.addObject("user", user);
		}else{
			model = new ModelAndView("login");
			model.addObject("errMsg", "User not Authorized");
		}
		return model;
	}

	@RequestMapping("/flightInfo.do")
	public ModelAndView getFlightInfo(HttpServletRequest request) {
		ModelAndView model = null;
		List<FlightInfo> fList = null;
		HttpSession session = request.getSession(false);

		try {
			fList = services.showAll();
			if(fList.isEmpty()){
				model = new ModelAndView("error");
				model.addObject("error","No Flights Available");
			}else{
				model = new ModelAndView("flightInfo");
				model.addObject("fList", fList);
			}
		} catch (BookingExceptions e) {
			model = new ModelAndView("error");
			model.addObject("error","No Flights Available");
		}
		return model;
	}

	@RequestMapping("/addFlight.do")
	public ModelAndView addFlightInfo(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView model = new ModelAndView("addFlight");
		return model;
	}

	@RequestMapping("/successInsert.do")
	public ModelAndView successInsert(HttpServletRequest request,HttpServletResponse response) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		FlightInfo info = new FlightInfo();
		info.setFlightno(request.getParameter("flightNo"));
		info.setAirlinename(request.getParameter("airLine"));
		String source=request.getParameter("src");
		info.setDept_city(request.getParameter("src"));
		String destination=request.getParameter("dest");
		info.setArr_city(request.getParameter("dest"));

		try {
			String d = request.getParameter("dDate").toString();
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date = sdf1.parse(d);
			java.sql.Date sqldeptDate = new Date(date.getTime());
			System.out.println(sqldeptDate);
			info.setDep_date(sqldeptDate);

			String a = request.getParameter("aDate").toString();
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date1 = sdf2.parse(d);
			java.sql.Date sqlarrDate = new Date(date1.getTime());
			System.out.println(sqlarrDate);
			info.setArr_date(sqlarrDate);
		

		info.setDep_time(request.getParameter("dTime"));
		info.setArr_time(request.getParameter("aTime"));

		String fseat = request.getParameter("fSeats");
		info.setFirstseats(Integer.parseInt(fseat));

		String fSeatFare = request.getParameter("fSeatsFare");
		info.setFirstseatfare(Integer.parseInt(fSeatFare));

		String bseat = request.getParameter("bSeats");
		info.setBussseats(Integer.parseInt(bseat));

		String bSeatfare = request.getParameter("bSeatsFare");
		info.setBussseatfare(Integer.parseInt(bSeatfare));
		
		
			services.insertFlightDetails(info);
			String flightCode = request.getParameter("flightNo");
			String flightName = request.getParameter("airLine");
			
			model = new ModelAndView("successInsert");
			model.addObject("flightNo", flightCode);
			model.addObject("airLine", flightName);
		
		} catch (BookingExceptions | ParseException e1) {
			String errMsg = "Flight Data not inserted";
			
			model = new ModelAndView("addFlight");
			model.addObject("error", errMsg);
		}
		return model;
	}

	@RequestMapping("/updateFlightDetails.do")
	public ModelAndView updateFlightDetails(HttpServletRequest request,@RequestParam("id") String id) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		try {
			FlightInfo flight = services.flightDetails(id);
			model = new ModelAndView("updateFlightDetails");
			model.addObject("flight", flight);
		} catch (BookingExceptions e) {
			model = new ModelAndView("updateFlightDetails");
			model.addObject("error","Flight updation failed");
		}

		return model;
	}

	@RequestMapping("/updatedFlightDetails.do")
	public ModelAndView updatedFlightDetails(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView model = null;
		FlightInfo updateInfo = new FlightInfo();
		updateInfo.setFlightno(request.getParameter("flightNo"));
		updateInfo.setAirlinename(request.getParameter("airLine"));
		updateInfo.setDept_city(request.getParameter("src"));
		updateInfo.setArr_city(request.getParameter("dest"));
		try {
			String d = request.getParameter("dDate").toString();
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date = sdf1.parse(d);
			java.sql.Date sqldeptDate = new Date(date.getTime());
			System.out.println(sqldeptDate);
			updateInfo.setDep_date(sqldeptDate);

			String a = request.getParameter("aDate").toString();
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date1 = sdf2.parse(d);
			java.sql.Date sqlarrDate = new Date(date1.getTime());
			System.out.println(sqlarrDate);
			updateInfo.setArr_date(sqlarrDate);
		
		updateInfo.setDep_time(request.getParameter("dTime"));
		updateInfo.setArr_time(request.getParameter("aTime"));

		String updateFseat = request.getParameter("fSeats");
		updateInfo.setFirstseats(Integer.parseInt(updateFseat));

		String updatefSeatFare = request.getParameter("fSeatsFare");
		updateInfo.setFirstseatfare(Integer.parseInt(updatefSeatFare));

		String updateBseat = request.getParameter("bSeats");
		updateInfo.setBussseats(Integer.parseInt(updateBseat));

		String updateBSeatfare = request.getParameter("bSeatsFare");
		updateInfo.setBussseatfare(Integer.parseInt(updateBSeatfare));
		
			boolean update = services.updateFlightInfo(updateInfo);
			String f = request.getParameter("flightNo");
			
			model = new ModelAndView("successUpdate");
			model.addObject("flightNo", f);
		} catch (BookingExceptions | ParseException e2) {
			String errMsg = "Failed to update flight information";
			
			model = new ModelAndView("error");
			model.addObject("error", errMsg);
		}
		return model;
	}

	@RequestMapping("/deleteFlights.do")
	public ModelAndView deleteEmp(HttpServletRequest request,@RequestParam("id") String id) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		try {
			//String no1 = request.getParameter("id");
			boolean updateCancel = services.updateCancelFlight(id);
			if(updateCancel){
				boolean status = services.deleteFlight(id);
				if (status == true) {
					model = new ModelAndView("successDelete");
					model.addObject("flightNo", id);
				}
			}
		} catch (BookingExceptions e) {
			model = new ModelAndView("error");
			model.addObject("error","Flight cancellation failed");
		}

		return model;
	}

	@RequestMapping("/srsDes.do")
	public ModelAndView bySrcdest(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		model = new ModelAndView("searchBySrcDes");
		return model;
	}

	@RequestMapping("/seacrchFlight.do")
	public ModelAndView searchFlight(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		String src = request.getParameter("source");
		String dest = request.getParameter("destination");
		List<FlightInfo> searchList = null;
		try {
			searchList = services.searchBySrcDest(src, dest);
			if(searchList.isEmpty()){
				String errMsg = "No Flights for this Source and Destination.";				
				model = new ModelAndView("searchBySrcDes");
				model.addObject("error", errMsg);
			}else{
				//request.setAttribute("sList", searchList);
				model = new ModelAndView("successSearch");
				model.addObject("sList", searchList);
			}
		} catch (BookingExceptions e) {
			String errMsg = "No Flights for this Source and Destination.";				
			model = new ModelAndView("searchBySrcDes");
			model.addObject("error", errMsg);
		}

		return model;
	}

	@RequestMapping("/passengerList.do")
	public ModelAndView passengerList(HttpServletRequest request) {
		ModelAndView model = null;
		model = new ModelAndView("searchFlightPassengers");
		return model;
	}

	@RequestMapping("/passengerListDisplay.do")
	public ModelAndView passengerListDisplay(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		ModelAndView model = null;
		String flightno = request.getParameter("flightNo");
		System.out.println("flightno"+flightno);
		List<BookingInformation> passengerList = null;
		try {
			passengerList = services.showPassengerList(flightno);
			if(passengerList.isEmpty()){
				String errMsg = "No Booking done for this flight or Flight does not exist.";				
				model = new ModelAndView("searchFlightPassengers");
				model.addObject("flightNo", flightno);
				model.addObject("pList", passengerList);
				model.addObject("error", errMsg);
			}else{
				model = new ModelAndView("passengerList");
				model.addObject("flightNo", flightno);
				model.addObject("pList", passengerList);
			}
		} catch (BookingExceptions e1) {
			String errMsg = "No Booking done for this flight or Flight does not exist.";				
			model = new ModelAndView("searchFlightPassengers");
			model.addObject("flightNo", flightno);
			model.addObject("pList", passengerList);
			model.addObject("error", errMsg);
		}
		return model;
	}

	@RequestMapping("/executive.do")
	public ModelAndView getExecutivePage(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		model = new ModelAndView("executive");
		return model;
	}
	
	@RequestMapping("/registerUser.do")
	public ModelAndView getregisterPage() {
		ModelAndView model = null;
		model = new ModelAndView("register");
		return model;
	}

	@RequestMapping("/register.do")
	public ModelAndView getRegisterPage(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		String fName = request.getParameter("fName");
		String lName = request.getParameter("lName");
		String uName = request.getParameter("uName");
		String pass = request.getParameter("password");
		String role = "user";
		String mobile = request.getParameter("phone");
		UserClass users = new UserClass();
		users.setFirstName(fName);
		users.setLastName(lName);
		users.setUsername(uName);
		users.setPassword(pass);
		users.setRole(role);
		users.setMobile_no(mobile);
		try {
			boolean insert = services.insertUser(users);
			if (insert == true) {
				
				model = new ModelAndView("RegisteredUser");
				model.addObject("fName", fName);
				model.addObject("lName", lName);
				model.addObject("uName", uName);
				model.addObject("mobile", mobile);
			}
		} catch (BookingExceptions e) {
			String errMsg = "Registration Failed";
			
			model = new ModelAndView("error");
			model.addObject("error", errMsg);
		}
		return model;
	}

	@RequestMapping("/user.do")
	public ModelAndView getUserPage(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		model = new ModelAndView("userFunctions");
		return model;
	}

	@RequestMapping("/getAllFlightDetails.do")
	public ModelAndView getAllFlightDetails(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		try {
			List<FlightInfo> flightList = services.showAll();
			
			model = new ModelAndView("flightDetails");
			model.addObject("flist", flightList);

		} catch (BookingExceptions e) {
			String errMsg = "No Flights Found";
			
			model = new ModelAndView("userFunctions");
			model.addObject("error", errMsg);
			
		}
		return model;
	}

	@RequestMapping("/searchDate.do")
	public ModelAndView getSearchDate(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		model = new ModelAndView("searchByDate");
		return model;
	}

	@RequestMapping("/searchByDate.do")
	public ModelAndView searchByDate(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		List<FlightInfo> infoList = null;;
		try {
			String d = request.getParameter("dateSearch").toString();
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date = sdf1.parse(d);
			java.sql.Date sqldeptDate = new Date(date.getTime());
			infoList = services.showFlightByDate(sqldeptDate);
			if(infoList.isEmpty()){
				String errMsg = "No Flights Found for selected Date";
				model = new ModelAndView("searchByDate");
				model.addObject("fList", infoList);
				model.addObject("error", errMsg);
			}
			else{
			model = new ModelAndView("searchFlights");
			model.addObject("fList", infoList);
			}
		} catch (ParseException | BookingExceptions e1) {
			String errMsg = "No Flights Found for selected Date";
			model = new ModelAndView("searchByDate");
			model.addObject("fList", infoList);
			model.addObject("error", errMsg);
		}
		return model;
	}

	@RequestMapping("/bookFlightDetails.do")
	public ModelAndView bookFlightDetails(@RequestParam("id") String flightId,@RequestParam("src") String flightSrc,@RequestParam("dest") String flightDest,HttpSession session) {
		String userName=(String) session.getAttribute("user");
		ModelAndView model = new ModelAndView("book");
		model.addObject("userName", userName);
		model.addObject("flightCode", flightId);
		model.addObject("flightSrc", flightSrc);
		model.addObject("flightDest", flightDest);
		model.addObject("booking", new BookingInformation());
		return model;
	}
	/*,@RequestParam("id") String flightId,@RequestParam("src") String flightSrc,@RequestParam("dest") String flightDest,*/
	@RequestMapping("/booked.do")
	public ModelAndView booked(@ModelAttribute("booking")  @Valid BookingInformation booking,BindingResult result,HttpSession session) {
		ModelAndView model;
		String userName=(String) session.getAttribute("user");
		String flightId = booking.getFlightno();
		String flightSrc = booking.getSrc_city();
		String flightDest = booking.getDest_city();
		if(result.hasErrors())
		{
			System.out.println(result.getAllErrors());	
			model = new ModelAndView("book");
			model.addObject("flightCode", flightId);
			model.addObject("flightSrc", flightSrc);
			model.addObject("flightDest", flightDest);
			model.addObject("booking", new BookingInformation());
			return model;
			
		}
		
		try {
			    booking.setUserName(userName);
				BookingInformation booked = services.addBookingDetails(booking,flightId);
			    String bookid=booked.getBooking_id();
			    String flightno=booked.getFlightno();
			    int totalPassenger=booked.getNo_of_passenger();
			    String classType=booked.getClass_type();
			     
				boolean flightSeatUpdate = services.updateFlightSeatQuantity(flightno, totalPassenger, classType);
				System.out.println(flightSeatUpdate);
				String bookedId=booked.getBooking_id();
				System.out.println("In control book"+bookedId);
				BookingInformation bookingID = services.showBookingId(bookedId);
				String bookId=bookingID.getBooking_id();
				System.out.println(bookId);
				model = new ModelAndView("successBooking");
				model.addObject("bookid", bookId);	
				model.addObject("booking",booked);
				model.addObject("userName",userName);
		
		}  catch (BookingExceptions e) {
			String errMsg = "Booking Failed. Try again.";
			model = new ModelAndView("book");
			model.addObject("error", errMsg);
			
		}
		return model;
	}
		
		

	@RequestMapping("/bookingDetails.do")
	public ModelAndView getBookingDetails(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		String bookid = request.getParameter("id");
		BookingInformation bookedDetails = null;
		try {
			bookedDetails = services.showBookingDetails(bookid);
			
			model = new ModelAndView("bookingDetails");
			model.addObject("bookedDetails", bookedDetails);
		} catch (BookingExceptions e) {
			String errMsg = "No Booking Details Found";
			
			model = new ModelAndView("error");
			model.addObject("error", errMsg);
		}
		return model;
	}
	
	@RequestMapping("/userBookingList.do")
	public ModelAndView getUserBookingDetails(HttpSession session)
	{
		ModelAndView model = null;
		BookingInformation bookedDetails = null;
		String userName=(String) session.getAttribute("user");
		try {
			List<BookingInformation> bookedDetailsList = services.listBookingDetails(userName);
			if(bookedDetailsList.isEmpty())
			{
				String errMsg = "No Bookings Found";
				model = new ModelAndView("userFunctions");
				model.addObject("error", errMsg);
			}
			else{
				model = new ModelAndView("bookingDetailsList");
				model.addObject("bookedDetailsList", bookedDetailsList);
				model.addObject("userName", userName);
			}
		
			
		} catch (BookingExceptions e) {
			String errMsg = "No Booking Details Found for this user";
			model = new ModelAndView("userFunctions");
			model.addObject("error", errMsg);
		}
		return model;
	}
	

	@RequestMapping("/cancelBooking.do")
	public ModelAndView cancelBooking(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);
		String bookid = request.getParameter("id");
		String seatType = request.getParameter("name");
		System.out.println("Cancel id" + bookid);
		try {
			BookingInformation bookedDetails = services.showBookingDetails(bookid);
			boolean update = services.updateFlightSeatQuantityOnCancellation(bookedDetails.getFlightno(),bookedDetails.getNo_of_passenger(), seatType);
			boolean canceledTicket = services.cancelBooking(bookid);
			System.out.println("Flight Seats updated on cancel" + update);
			
			model = new ModelAndView("successCancel");
			model.addObject("bookid", bookid);
		} catch (BookingExceptions e) {
			String errMsg = "Cancellation Failed ";
			
			model = new ModelAndView("error");
			model.addObject("error", errMsg);
		}
		return model;
	}

	@RequestMapping("/logout.do")
	public ModelAndView logout(HttpServletRequest request) {
		ModelAndView model = null;
		HttpSession session = request.getSession(false);// to close session or
														// get the old session
														// and not create new
														// session
		session.invalidate();// Destroys a session.
		// ctx.log("session invalidated");
		model = new ModelAndView("home");
		
		return model;
	}

	public void destroy() {
		services = null;
		// ctx.log("In destroy");
	}
	
}
