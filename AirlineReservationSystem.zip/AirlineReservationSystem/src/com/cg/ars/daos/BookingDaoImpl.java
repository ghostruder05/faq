package com.cg.ars.daos;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.ars.entities.BookingInformation;
import com.cg.ars.entities.FlightInfo;
import com.cg.ars.entities.UserClass;
import com.cg.ars.exceptions.BookingExceptions;

import javax.persistence.TypedQuery;

@Repository("bookingDao")
public class BookingDaoImpl implements BookingDao {
	
	@PersistenceContext
    private EntityManager manager;

	@Override
	public List<FlightInfo> showAll() throws BookingExceptions {
		Query qry = manager.createQuery("select f from flightInfo f", FlightInfo.class);
		return qry.getResultList();
	}

	@Override
	public FlightInfo flightDetails(String flightno) throws BookingExceptions {
		FlightInfo flight=manager.find(FlightInfo.class, flightno);
		return flight;
	}

	@Override
	public BookingInformation addBookingDetails(BookingInformation book, String no) throws BookingExceptions {
		
		String flightNo = book.getFlightno();	//System.out.println(flightNo);
		int passenger = book.getNo_of_passenger();	//System.out.println(passenger);
		String seaType = book.getClass_type();		//System.out.println(seaType);
		int fare=getSeatFare(flightNo,passenger,seaType); //System.out.println(fare);
		book.setTotal_fare(fare);
		manager.persist(book);
		System.out.println(book.toString());	
		
		String id = book.getBooking_id();
		System.out.println("In Dao bid "+id);
		
		
		return book;
	}
	
	@Override
	public boolean cancelBooking(String bookid) throws BookingExceptions {
		BookingInformation book=new BookingInformation();
		book.setBooking_id(bookid);
		book=manager.find(BookingInformation.class, bookid);
		manager.remove(book);
		return true;
	}

	@Override
	public BookingInformation showBookingId(String id) throws BookingExceptions {
		//EntityManager manager=factory.createEntityManager();
		TypedQuery<BookingInformation> booking=manager.createNamedQuery("bookingIdSelect",BookingInformation.class);
		booking.setParameter("bookId",id);
		System.out.println("In Dao showBookingId(String id)"+id);
		BookingInformation book=booking.getSingleResult();
		/*String bid=book.getBooking_id();
		System.out.println("showBookingId(String email)"+bid);*/
		return book;
	}

	@Override
	public UserClass getUserDetails(String userName) throws BookingExceptions {
		UserClass user=manager.find(UserClass.class, userName);
		return user;
	}

	@Override
	public BookingInformation showBookingDetails(String bookId)
			throws BookingExceptions {
		BookingInformation book=manager.find(BookingInformation.class, bookId);
		return book;
	}

	@Override
	public boolean updateFlightSeatQuantity(String flightno,int noofpassengers, String seattype) throws BookingExceptions {
		TypedQuery<FlightInfo> flight1=manager.createNamedQuery("findFLightonFlightNO",FlightInfo.class);
		flight1.setParameter("fno", flightno);
		FlightInfo flight=flight1.getSingleResult();
		System.out.println("flight string"+flight.toString());
			if(seattype.equals("Business")){	
				
			/*TypedQuery<FlightInfo> qry = manager.createNamedQuery("updateFlightOnBookBusiness",FlightInfo.class);
			qry.setParameter("seats", noofpassengers);
			qry.setParameter("fno", flightno);
			qry.getSingleResult();*/
				
				int seats=flight.getBussseats();
				System.out.println("Seats"+seats);
				int updatedSeats=seats-noofpassengers;
				flight.setBussseats(updatedSeats);
				manager.merge(flight);
				System.out.println("Updated Business seats");
				
			}else if(seattype.equals("First")){
				

				int seats=flight.getFirstseats();
				System.out.println("First Seats"+seats);
				int updatedSeats=seats-noofpassengers;
				flight.setFirstseats(updatedSeats);
				manager.merge(flight);
				System.out.println("Updated First seats");
				
				/*	TypedQuery<FlightInfo> qry = manager.createNamedQuery("updateFlightOnBookFirst",FlightInfo.class);
					qry.setParameter("seats", noofpassengers);
					qry.setParameter("fno", flightno);
					qry.getSingleResult();*/
			}
		return true;
	}

	@Override
	public String getFlightNo(String src, String dest) throws BookingExceptions {
		TypedQuery<FlightInfo> qry= manager.createNamedQuery("searchBySrcDest",FlightInfo.class);	
		qry.setParameter("from", src);
		qry.setParameter("to", dest);
		FlightInfo finfo=qry.getSingleResult();
		System.out.println("finfo");
		String fno=finfo.getFlightno();
		return fno;
	}

	@Override
	public boolean updateFlightInfo(FlightInfo info) throws BookingExceptions {
		manager.merge(info);
		return true;
	}

	@Override
	public boolean deleteFlight(String no) throws BookingExceptions {
		 
		 /*TypedQuery<BookingInformation> qry= manager.createNamedQuery("setFlightNo",BookingInformation.class);	
		 qry.setParameter("fno", no);
		 BookingInformation updateflight=qry.getSingleResult();
		 String flightNo=updateflight.getFlightno();*/
		 TypedQuery<FlightInfo> flight= manager.createNamedQuery("cancelFlight", FlightInfo.class);
		 //flight.setParameter("status", null);
		 flight.setParameter("fno", no);
		 FlightInfo setFlightNull=flight.getSingleResult();
		 
		 manager.remove(setFlightNull);
		return true;
	}
	
	@Override
	public boolean updateCancelFlight(String no) throws BookingExceptions {
		TypedQuery<BookingInformation> flight= manager.createNamedQuery("passList", BookingInformation.class);
		flight.setParameter("fno", no);
		List<BookingInformation> flightList = flight.getResultList();
		for (BookingInformation bookingInformation : flightList) {
			bookingInformation.setFlightno(null);
			
		}
		return true;
	}

	@Override
	public boolean insertFlightDetails(FlightInfo info)
			throws BookingExceptions {
		manager.persist(info);
		return true;
	}

	@Override
	public boolean insertUsers(UserClass users) throws BookingExceptions {
		manager.persist(users);
		return true;
	}

	@Override
	public List<FlightInfo> searchBySrcDest(String src, String dest)
			throws BookingExceptions {
	
		TypedQuery<FlightInfo> qry= manager.createNamedQuery("listFlightBySrcDest",FlightInfo.class);	
		qry.setParameter("from", src);
		qry.setParameter("to", dest);
		return qry.getResultList();
		
	}

	@Override
	public int getSeatFare(String flightno, int noofpassengers, String seattype)
			throws BookingExceptions {
	    int fare = 0;
		if(seattype.equals("Business"))
		{
			TypedQuery<FlightInfo> qry= manager.createNamedQuery("seatFare",FlightInfo.class);	
			qry.setParameter("fno", flightno);
			FlightInfo finfo=qry.getSingleResult();	
			fare=finfo.getBussseatfare();  
		}
		else if(seattype.equals("First"))
		{  
		  TypedQuery<FlightInfo> qry= manager.createNamedQuery("seatFare",FlightInfo.class);	
		  qry.setParameter("fno", flightno);
		  FlightInfo finfo=qry.getSingleResult();
		 
		  fare=finfo.getBussseatfare();  
		}
		
		 System.out.println("flight seats fare");
 		 int totalfare=noofpassengers*fare;
 		 return totalfare;
 		}
 			


	@Override
	public List<FlightInfo> showFlightByDate(Date date)
			throws BookingExceptions {
		TypedQuery<FlightInfo> qry= manager.createNamedQuery("showFlightByDate",FlightInfo.class);	
		qry.setParameter("depdate", date);
		return qry.getResultList();
	
	}

	@Override
	public boolean updateFlightSeatQuantityOnCancellation(String flightno,int noofpassengers, String seattype) throws BookingExceptions {
		
		TypedQuery<FlightInfo> qry = manager.createNamedQuery("findFLightonFlightNO", FlightInfo.class);
		//qry.setParameter("seats", noofpassengers);
		qry.setParameter("fno", flightno);
		FlightInfo flight=qry.getSingleResult();
		
		if(seattype.equals("Business")){			
			
			int seats=flight.getBussseats();
			System.out.println("Seats"+seats);
			int updatedSeats=seats+noofpassengers;
			flight.setBussseats(updatedSeats);
			
			manager.merge(flight);
			System.out.println("Flight Business Seats Updated on Cancel");
			
		}else if(seattype.equals("First")){
					
			int seats=flight.getFirstseats();
			System.out.println("First Seats"+seats);
			int updatedSeats=seats+noofpassengers;
			flight.setFirstseats(updatedSeats);
			
			manager.merge(flight);
			System.out.println("Flight First Seats Updated on Cancel");
		}
		return true;
	}

	@Override
	public List<BookingInformation> showPassengerList(String flightno)
			throws BookingExceptions {
		System.out.println("In Dao Flightno"+flightno);
		//TypedQuery<BookingInformation> qry = manager.createNamedQuery("SELECT flightno,booking_id,cust_email,no_of_passengers,class_type FROM bookingInformation WHERE flightno=:fno ",BookingInformation.class);
		//Query qry=manager.createQuery("SELECT flightno,booking_id,cust_email,no_of_passengers,class_type FROM bookingInformation WHERE flightno=:fno ",BookingInformation.class);
		TypedQuery<BookingInformation> qry = manager.createNamedQuery("passList",BookingInformation.class);
		qry.setParameter("fno", flightno);
		System.out.println(qry.getResultList().toString());
		return qry.getResultList();
	}

	@Override
	public List<BookingInformation> listBookingDetails(String userName)
			throws BookingExceptions {
		TypedQuery<BookingInformation> qry = manager.createNamedQuery("bookList",BookingInformation.class);
		qry.setParameter("userName", userName);
		System.out.println(qry.getResultList().toString());
		return qry.getResultList();
	}

	

}
